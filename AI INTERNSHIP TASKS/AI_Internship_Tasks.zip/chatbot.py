
# chatbot.py
# Rule-Based Chatbot

def chatbot_response(user_input):
    user_input = user_input.lower()
    if "hello" in user_input or "hi" in user_input:
        return "Hello! How can I assist you today?"
    elif "help" in user_input:
        return "Sure! I'm here to help. Ask me anything."
    elif "bye" in user_input:
        return "Goodbye! Have a great day!"
    else:
        return "I'm not sure how to respond to that."

# Interactive loop
if __name__ == "__main__":
    print("Chatbot: Hello! Type 'bye' to exit.")
    while True:
        user = input("You: ")
        response = chatbot_response(user)
        print("Chatbot:", response)
        if user.lower() in ["bye", "exit", "quit"]:
            break
