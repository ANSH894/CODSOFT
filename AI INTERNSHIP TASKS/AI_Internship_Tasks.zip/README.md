
# AI Internship Tasks

This repository contains solutions to three core AI tasks completed as part of an Artificial Intelligence internship. Each task demonstrates fundamental AI and machine learning concepts using Python.

---

## 📌 Tasks Included

### 1. 🤖 Rule-Based Chatbot
A simple chatbot that responds to user inputs based on predefined rules using `if-else` conditions.

**How to run:**
```bash
python chatbot.py
```

---

### 2. ❌⭕ Tic-Tac-Toe AI (Minimax)
An unbeatable Tic-Tac-Toe AI using the Minimax algorithm. You play as **X**, and the AI plays as **O**.

**How to run:**
```bash
python tictactoe_ai.py
```

---

### 3. 🖼️ Image Captioning
This task generates natural language captions from an image using a pretrained Vision-Encoder-Decoder Transformer model.

**Dependencies:**
```bash
pip install transformers torch torchvision pillow requests
```

**How to run:**
```bash
python image_captioning.py
```

---

## 💡 Requirements
- Python 3.7 or above
- Internet connection (for downloading pretrained models/images)
- Optional: GPU (for faster image captioning)

---

## 📂 Project Structure
```
AI-Internship-Tasks/
│
├── chatbot.py              # Task 1: Rule-Based Chatbot
├── tictactoe_ai.py         # Task 2: Tic-Tac-Toe with Minimax
├── image_captioning.py     # Task 3: Image Captioning with Transformers
└── README.md               # This file
```

---

## 🏁 Getting Started

1. Clone the repository:
```bash
git clone https://github.com/your-username/AI-Internship-Tasks.git
cd AI-Internship-Tasks
```

2. Run any task using Python as described above.

---

## 🙋‍♀️ Author
Created by Paloma ✨ as part of an AI Internship Project.

---

## 📜 License
This project is for educational purposes and open-source learning.
