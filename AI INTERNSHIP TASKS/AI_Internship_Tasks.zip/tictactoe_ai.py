
# tictactoe_ai.py
# Tic-Tac-Toe AI using Minimax

import math

def print_board(board):
    for row in board:
        print(" | ".join(row))
        print("-" * 5)

def is_winner(board, player):
    win_states = [
        [board[0][0], board[0][1], board[0][2]],
        [board[1][0], board[1][1], board[1][2]],
        [board[2][0], board[2][1], board[2][2]],
        [board[0][0], board[1][0], board[2][0]],
        [board[0][1], board[1][1], board[2][1]],
        [board[0][2], board[1][2], board[2][2]],
        [board[0][0], board[1][1], board[2][2]],
        [board[0][2], board[1][1], board[2][0]],
    ]
    return [player, player, player] in win_states

def get_empty_cells(board):
    return [(i, j) for i in range(3) for j in range(3) if board[i][j] == " "]

def minimax(board, is_maximizing):
    if is_winner(board, "O"):
        return 1
    elif is_winner(board, "X"):
        return -1
    elif not get_empty_cells(board):
        return 0

    if is_maximizing:
        best = -math.inf
        for i, j in get_empty_cells(board):
            board[i][j] = "O"
            score = minimax(board, False)
            board[i][j] = " "
            best = max(best, score)
        return best
    else:
        best = math.inf
        for i, j in get_empty_cells(board):
            board[i][j] = "X"
            score = minimax(board, True)
            board[i][j] = " "
            best = min(best, score)
        return best

def best_move(board):
    best_score = -math.inf
    move = None
    for i, j in get_empty_cells(board):
        board[i][j] = "O"
        score = minimax(board, False)
        board[i][j] = " "
        if score > best_score:
            best_score = score
            move = (i, j)
    return move

if __name__ == "__main__":
    board = [[" "] * 3 for _ in range(3)]
    print("You are X, AI is O")
    while True:
        print_board(board)
        x, y = map(int, input("Enter row and column (0-2): ").split())
        if board[x][y] == " ":
            board[x][y] = "X"
        else:
            print("Invalid move. Try again.")
            continue
        if is_winner(board, "X") or not get_empty_cells(board):
            break
        i, j = best_move(board)
        board[i][j] = "O"
        if is_winner(board, "O") or not get_empty_cells(board):
            break
    print_board(board)
    if is_winner(board, "X"):
        print("You win!")
    elif is_winner(board, "O"):
        print("AI wins!")
    else:
        print("It's a draw!")
